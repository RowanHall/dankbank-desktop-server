var fs = require('fs')
module.exports = {
  getuuid: () => {
    return (JSON.parse(fs.readFileSync(__dirname + '/../../account.JSON', 'utf-8')).uuid)
  }
}