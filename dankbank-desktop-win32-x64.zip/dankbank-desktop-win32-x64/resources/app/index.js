const { app, BrowserWindow, ipcMain } = require('electron')
const fs = require('fs');
const account = require(__dirname + '/src/accountmanager/index.js')
var clientID = require('uuid/v4')();
var lasturl = ""
if(fs.existsSync(__dirname + "/googleanalytics.txt")) {
  clientID = fs.readFileSync(__dirname + "/googleanalytics.txt", "utf-8")
} else {
  fs.writeFileSync(__dirname + "/googleanalytics.txt", clientID)
}

const Analytics  = require('electron-google-analytics');
const analytics = new Analytics.default('UA-142999629-3');
 
function screen(screenname){
  analytics.pageview('http://electron.dev/', '/' + screenname, screenname)
  .then((response) => {
    return response;
  }).catch((err) => {
    return err;
  });
    return analytics.screen('DankBank Desktop', '1.0.0', 'noAppID', 'noInstallerID', screenname, clientID)
  .then((response) => {
    return response;
  }).catch((err) => {
    return err;
  });
}

function analyticsevent(eventcatagory, eventaction, eventlabel, eventvalue) {
  return analytics.event(eventcatagory, eventaction, { evLabel: eventaction, evValue: eventvalue, clientID: clientID})
  .then((response) => {
    return response;
  }).catch((err) => {
    return err;
  });
}

function createWindow () {
  win = new BrowserWindow({
    width: 1185,
    height: 750,
    webPreferences: {
      nodeIntegration: true
    },
    minWidth: 1185,
    minHeight: 750,
    frame: false
  })

  if(account.getuuid()) {
    win.loadFile(__dirname + "/src/frontend/home/index.html")
  } else {
    win.loadFile(__dirname + "/src/frontend/notauthed/index.html")
  }

  win.on('closed', () => {
    win = null
  })
  setInterval(() => {
    try {
      var url = win.webContents.getURL()
      if(url != lasturl) {
        var a = screen(url.split('/')[url.split('/').length - 2])
      }
      lasturl = url;
    } catch(err) {}
  })
}

app.on('ready', createWindow)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (win === null) {
    createWindow()
  }
})

ipcMain.on('analytics', (author, data) => {
  analyticsevent(data.catagory, data.action, data.label, data.value)
})